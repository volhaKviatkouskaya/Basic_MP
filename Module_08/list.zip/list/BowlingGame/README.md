## Bowling Game Kata

* Create a new project or start in the existing project by adding Game.cs and TestGame.cs
* Create two public methods methods [refer to the presentation file]
* Create Test Methods for the above Methods
* This is called a 'RED' Test as it is going to fail.
* Rectified both test and class methods
* Write new test
* This is called a 'Green' Test as it is going to pass.
* Rectified TestMethods to meet total 20 frames hit.
* Rectified test to accept multiple frame and pins
* Test 3 is a 'Red' test
* Test 4 and 5 are 'Green'
* All test passed
* Still there is scope of refactoring

#### References

* Uncle Bob [Bowling Game Kata](http://butunclebob.com/ArticleS.UncleBob.TheBowlingGameKata)