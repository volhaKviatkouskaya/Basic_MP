## Calc Stats Kata

Your task is to process a sequence of integer numbers
to determine the following statistics:

* minimum value
* maximum value
* number of elements in the sequence
* average value

For example: [6, 9, 15, -2, 92, 11]

* minimum value = -2
* maximum value = 92
* number of elements in the sequence = 6
* average value = 18.166666