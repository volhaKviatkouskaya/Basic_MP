### Natural Order String Sorting

There is no built-in feature available in .Net to provide us Natural String Order Soring.

#### What is Natural Order String Sorting?

Almost all framework provided ASCII order Sorting so, in case of string list : 1,2,3...,1A,2S the result would be as per ASCII order
But in Natural Order String this should be : 1,1A,2,2S,3... etc.

