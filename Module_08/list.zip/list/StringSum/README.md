## String Sum Kata

* Write a simple String Sum utility with a function <em>string Sum(string num1, string num2)</em>, which can accept only natural numbers and will return their sum. Replace entered number with <em>0 (zero)</em> if entered number is not a natural number.
* Stat with a simplest test case with an empty string
* Create a simple method <em>string Sum(string num1, string num2)</em>
* Write a test to pass small numbers and refactor, if test passed
* try to write more code and refactor
